local NoName = ...
local JSON = NoName.Utils.JSON
local Draw = NoName.Utils.Draw:New()
local afkme = NoName.Utils.AntiAFK
-- local aes = NoName.Utils.AESECB
local write = NoName.Utils.Storage.write
local aes = NoName.Utils.AES
local sha = NoName.Utils.sha

for v, k in pairs(Objects()) do
    if ObjectType(k) == 7 then
        print(UnitGUID(k))
    end
end

local abc = {"this", "that", "that", "other"}
local HiBy = JSON.encode(abc)
afkme() 
print("HiBy:", HiBy)
WriteFile("/testing.json", HiBy, false)
write("testing", "The key name is testing, and this is the value being saved.")
Draw:Sync(
    function(draw)
        local px, py, pz = ObjectPosition("player")
        local x, y, z = ObjectPosition("target")
        local map = select(8, GetInstanceInfo())
        if not x then
            return
        end
        ---print (GenerateLocalPath(map,px,py,pz,x,y,z))
        draw:SetAlpha(192)
        draw:SetColor(draw.colors.red)
        draw:Line(px, py, pz, x, y, z)
        draw:SetColor(draw.colors.green)
        if IsShiftKeyDown() then
            xx, yy, zz = LastTerrainClick()
            print(xx, yy, zz)
            draw:Circle(xx, yy, zz, 1.5)
        end

        draw:Circle(x, y, z, 1.5)
        draw:Text(
            (UnitName("target")) .. " (" .. Distance(px, py, pz, x, y, z) .. ")",
            "GameTooltipTextSmall",
            x,
            y,
            z + 0.25
        )
    end
)

Draw:Enable()



local iv = {0x1, 0x2, 0x3, 0x1, 0x2, 0x3, 0x1, 0x2, 0x3, 0x1, 0x2, 0x3, 0x1, 0x2, 0x3, 06}
local rawfile = ReadFile("/scripts/testme.lua")

local lomes = aes.encrypt("password", rawfile, aes.AES256, aes.CBCMODE, iv)
WriteFile("/scripts/aes256.aes", lomes, false)
print("Lomes::", lomes)

--print("Decrypted:", aes.decrypt("password", lomes, aes.AES256, aes.CBCMODE, iv))

-- RunScriptAES256CBC assumes that your starting folder is /scripts/
aes.RunScriptAES256CBC("aes256.aes", "password", iv)

print ('HMAC Inforamtion')
print (sha.sha256(rawfile)) 
print (sha.hmac_sha256('thisisakey', 'thisissometext'))
