local NoName = ...

-- If you want to automate this, the following you can use to read local files and deal with it on your own.
-- NoName.Utils = {}
-- NoName:Require("/lua/utils/JSON")
-- local JSON = NoName.Utils.JSON
-- local config = '/configs/relogger.json'
-- local rawdata = ReadFile(config)
-- local data = JSON.decode(rawdata)

-- Below, if you just want to keep your own local version of this file and not worry about a JSON file, use the following. Remark out if your using automated via JSON config file.
local data = {}

data.account = ""
data.username = ''
data.password = ''
data.realmname = ''
data.enabled = false
data.playerslot = 2 -- The toon poistion on the right hand side. Starting at the top.

if data.enabled then
    C_Timer.After(3, function()
        local timer
        timer = C_Timer.NewTicker(0.5, function()
            -- Reference the following for more options.
            -- https://github.com/tomrus88/BlizzardInterfaceCode/blob/master/Interface/GlueXML/AccountLogin.lua
            local mystate, _, _, hrl, wfrl = C_Login.GetState()
            if mystate == LE_AURORA_STATE_NONE and not wfrl and not hrl and
                GlueDialog:IsShown() then
                GlueDialog_Hide()
            end

            if GlueDialog:IsShown() then
                return
            end

            -- https://github.com/tomrus88/BlizzardInterfaceCode/blob/master/Interface/GlueXML/AccountLogin.lua
            if (AccountLogin and AccountLogin.UI.WoWAccountSelectDialog:IsShown()) then
                -- iterate over existing accounts and check for non case sensitive match
                local realAccount = data.account
                for i = 1, MAX_ACCOUNTNAME_DISPLAYED do
                    local accName = AccountLogin.UI.WoWAccountSelectDialog.gameAccounts[i]
                    if string.upper(accName) == string.upper(data.account) then
                        realAccount = accName
                        break
                    end
                end
                C_Login.SelectGameAccount(realAccount)
            elseif (AccountLogin and AccountLogin.UI:IsVisible()) then
                AccountLogin.UI.AccountEditBox:SetText(data.username)
                AccountLogin.UI.PasswordEditBox:SetText(data.password)
                AccountLogin_Login()
            elseif (RealmListUI and RealmListUI:IsVisible()) then
                local roptions = C_RealmList.GetAvailableCategories()
                for i = 1, #roptions do
                    local allrealms = C_RealmList.GetRealmsInCategory(roptions[i])
                    for j = 1, #allrealms do
                        local realmaddress = allrealms[j]
                        local realname, _ = C_RealmList.GetRealmInfo(realmaddress)
                        if realname == data.realmname then
                            RealmList.selectedRealm = realmaddress
                            RealmList_Update()
                            RealmList_OnOk()
                        end
                    end
                end
            elseif (CharacterSelect and CharacterSelect:IsVisible()) then
                -- https://www.ownedcore.com/forums/world-of-warcraft/world-of-warcraft-bots-programs/wow-memory-editing/302552-lua-auto-login-final-solution.html

                if GetServerName() ~= data.realmname and (not RealmList or not RealmList:IsVisible()) then
                    CharacterSelect_ChangeRealm()
                else
                    -- https://github.com/tomrus88/BlizzardInterfaceCode/blob/master/Interface/GlueXML/CharacterSelect.lua
                    if CharacterSelect_AllowedToEnterWorld() then
                        CharacterSelect_SelectCharacter(data.playerslot)
                        LastHardwareAction(GetTime() * 1000)
                        CharacterSelect_EnterWorld()
                    end
                end
            end
        end)
    end)
end
