Hi :)

Extract this .ZIP in a dedicated folder and run the Launcher of the product you want to run.

You can create a shortcut of the launcher on your desktop for more conveniance,

Each time you run the Launcher, it will delete the previous .exe and generate a new one to assure security.

Each .exe have a generated name, so it is normal if you have mlsqjlmqskjfmlq.exe in your folder ;-)

-> Because we send keystrokes/move the mouse/Connect to Internet (for update & license validation), the bot or Launcher might be considered as a virus by some AV.
Don't worry, it is absolutely harmless to you computer (False positive). You don't even have to run it as administrator :-)

Hope you enjoy !
